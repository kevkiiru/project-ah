"use client";

import { useQuery } from "@tanstack/react-query";
import { properties } from "@/lib/sample-data";

export function useProperties() {
  return useQuery({
    queryKey: ["properties"],
    queryFn: async () => {
      const response = await fetch("/api/properties", { cache: "no-store" });
      if (!response.ok) return properties;
      return response.json();
    },
    initialData: properties
  });
}
