import type { Property } from "@/types/property";

export const vibeTags = [
  "Minimalist",
  "Bohemian",
  "Luxury",
  "Cozy",
  "Industrial",
  "Family-Friendly",
  "Waterfront",
  "Urban",
  "Nature",
  "Smart Home",
  "Entertainer",
  "Historic",
  "Creative"
] as const;

const image = (id: string, property_id: string, query: string, order = 0) => ({
  id,
  property_id,
  url: `https://images.unsplash.com/${query}?auto=format&fit=crop&w=1600&q=85`,
  alt: "Beautiful luxury home interior",
  sort_order: order,
  is_hero: order === 0
});

export const properties: Property[] = [
  {
    id: "glass-house-austin",
    title: "Glass House Above Lake Austin",
    description: "A cinematic modern residence wrapped in glass, natural limestone, and warm oak with a pool terrace designed for sunset dinners.",
    price: 785000,
    location: "2408 Scenic Dr, Austin, TX",
    neighborhood: "Tarrytown",
    city: "Austin",
    state: "TX",
    beds: 3,
    baths: 2.5,
    sqft: 2480,
    lat: 30.3039,
    lng: -97.7815,
    vibe_tags: ["Minimalist", "Luxury", "Waterfront", "Smart Home"],
    ai_description: "Your calm-luxury match: clean architectural lines, lake-adjacent light, and seamless indoor-outdoor flow. Ideal for buyers who want sophistication without coldness.",
    ai_valuation: {
      estimate: 801000,
      confidence: 87,
      trend: "up",
      rationale: "Lake-adjacent inventory remains tight; renovated modern homes in Tarrytown are outperforming the broader Austin market.",
      comps: [
        { address: "1905 Rockmoor Ave", price: 815000, beds: 3, baths: 3, sqft: 2510, distanceMiles: 0.6 },
        { address: "2600 Cherry Ln", price: 774000, beds: 3, baths: 2, sqft: 2380, distanceMiles: 0.8 }
      ]
    },
    vibe_scores: { luxury: 92, calm: 88, family: 70, nightlife: 45, nature: 76, creative: 81 },
    status: "active",
    images: [
      image("img-a1", "glass-house-austin", "photo-1600607687939-ce8a6c25118c", 0),
      image("img-a2", "glass-house-austin", "photo-1600566753190-17f0baa2a6c3", 1),
      image("img-a3", "glass-house-austin", "photo-1600585154526-990dced4db0d", 2)
    ],
    agent: { name: "Mara Ellison", avatar: "ME", responseTime: "usually replies in 6 min" },
    created_at: "2026-06-01T10:00:00.000Z"
  },
  {
    id: "boho-bungalow-east-austin",
    title: "Sunlit Boho Bungalow",
    description: "A restored bungalow with plaster arches, handmade tile, edible garden, and a detached studio for creative work.",
    price: 612000,
    location: "1112 Holly St, Austin, TX",
    neighborhood: "East Austin",
    city: "Austin",
    state: "TX",
    beds: 3,
    baths: 2,
    sqft: 1810,
    lat: 30.2581,
    lng: -97.7186,
    vibe_tags: ["Bohemian", "Cozy", "Urban", "Historic", "Creative"],
    ai_description: "Warm, expressive, and walkable. This home scores high for creative energy, layered textures, and coffee-shop adjacency while staying practical for everyday life.",
    ai_valuation: {
      estimate: 623000,
      confidence: 82,
      trend: "flat",
      rationale: "Demand is stable for character homes in East Austin, with premium paid for updated systems and studio flexibility.",
      comps: [
        { address: "1308 Willow St", price: 599000, beds: 3, baths: 2, sqft: 1760, distanceMiles: 0.4 },
        { address: "907 E 2nd St", price: 640000, beds: 3, baths: 2, sqft: 1890, distanceMiles: 0.7 }
      ]
    },
    vibe_scores: { luxury: 66, calm: 78, family: 68, nightlife: 84, nature: 61, creative: 96 },
    status: "active",
    images: [
      image("img-b1", "boho-bungalow-east-austin", "photo-1600585154340-be6161a56a0c", 0),
      image("img-b2", "boho-bungalow-east-austin", "photo-1600566753086-00f18fb6b3ea", 1),
      image("img-b3", "boho-bungalow-east-austin", "photo-1600607687644-aac4c3eac7f4", 2)
    ],
    agent: { name: "Jules Carter", avatar: "JC", responseTime: "usually replies in 12 min" },
    created_at: "2026-05-24T10:00:00.000Z"
  },
  {
    id: "hill-country-retreat",
    title: "Hill Country Wellness Retreat",
    description: "A quiet family-forward hideaway with courtyards, pool, spa bath, outdoor kitchen, and sweeping greenbelt views.",
    price: 925000,
    location: "8701 Southwest Pkwy, Austin, TX",
    neighborhood: "Barton Creek",
    city: "Austin",
    state: "TX",
    beds: 4,
    baths: 3.5,
    sqft: 3260,
    lat: 30.2547,
    lng: -97.8739,
    vibe_tags: ["Family-Friendly", "Nature", "Luxury", "Entertainer"],
    ai_description: "Resort energy without leaving home. The layout balances quiet bedroom wings with generous gathering spaces, ideal for families who host often.",
    ai_valuation: {
      estimate: 944000,
      confidence: 90,
      trend: "up",
      rationale: "Greenbelt proximity, pool, and larger renovated homes are scarce and continue to command premium buyer attention.",
      comps: [
        { address: "8210 Chalk Knoll Dr", price: 930000, beds: 4, baths: 4, sqft: 3180, distanceMiles: 1.2 },
        { address: "9012 Wimberly Cv", price: 958000, beds: 4, baths: 3, sqft: 3375, distanceMiles: 1.6 }
      ]
    },
    vibe_scores: { luxury: 89, calm: 94, family: 92, nightlife: 30, nature: 97, creative: 62 },
    status: "active",
    images: [
      image("img-c1", "hill-country-retreat", "photo-1600047509807-ba8f99d2cdde", 0),
      image("img-c2", "hill-country-retreat", "photo-1600607687920-4e2a09cf159d", 1),
      image("img-c3", "hill-country-retreat", "photo-1600573472550-8090b5e0745e", 2)
    ],
    agent: { name: "Ari Mensah", avatar: "AM", responseTime: "usually replies in 4 min" },
    created_at: "2026-06-10T10:00:00.000Z"
  }
];

export function getProperty(id: string) {
  return properties.find((property) => property.id === id) ?? properties[0];
}
