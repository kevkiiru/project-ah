"use client";

import Image from "next/image";
import Link from "next/link";
import { motion } from "framer-motion";
import { Bath, BedDouble, Heart, MessageCircle, Share2, Sparkles } from "lucide-react";
import type { Property } from "@/types/property";
import { formatCurrency } from "@/lib/utils";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";

export function VibeFeed({ properties }: { properties: Property[] }) {
  return (
    <section className="feed-snap mx-auto flex max-h-[calc(100vh-7rem)] max-w-3xl flex-col gap-8 overflow-y-auto pb-24 pr-1">
      {properties.map((property) => (
        <motion.article
          key={property.id}
          className="feed-card relative min-h-[76vh] overflow-hidden rounded-[2.5rem] border border-white/10 bg-white/[0.05] shadow-luxe"
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, amount: 0.25 }}
        >
          <Image src={property.images[0].url} alt={property.title} fill sizes="100vw" className="object-cover" priority />
          <div className="absolute inset-0 bg-gradient-to-t from-black via-black/20 to-transparent" />
          <div className="absolute left-5 top-5 flex flex-wrap gap-2">
            {property.vibe_tags.map((tag) => <Badge key={tag} variant="vibe" className="bg-black/35 backdrop-blur">{tag}</Badge>)}
          </div>
          <div className="absolute bottom-0 left-0 right-16 space-y-5 p-6 md:right-24 md:p-8">
            <div>
              <p className="text-3xl font-semibold md:text-5xl">{formatCurrency(property.price)}</p>
              <h2 className="mt-2 font-display text-3xl md:text-5xl">{property.title}</h2>
              <p className="mt-3 max-w-2xl text-sm leading-6 text-white/75 md:text-base">{property.ai_description}</p>
            </div>
            <div className="flex flex-wrap items-center gap-3 text-sm text-white/80">
              <span className="rounded-full bg-white/10 px-4 py-2"><BedDouble className="mr-2 inline h-4 w-4" />{property.beds} beds</span>
              <span className="rounded-full bg-white/10 px-4 py-2"><Bath className="mr-2 inline h-4 w-4" />{property.baths} baths</span>
              <span className="rounded-full bg-white/10 px-4 py-2"><Sparkles className="mr-2 inline h-4 w-4" />{property.ai_valuation.confidence}% match</span>
            </div>
            <Button asChild variant="luxury" size="lg">
              <Link href={`/property/${property.id}`}>Tour this vibe</Link>
            </Button>
          </div>
          <div className="absolute bottom-8 right-4 flex flex-col gap-3 md:right-8">
            <Button variant="outline" size="icon" className="bg-black/30"><Heart className="h-5 w-5" /></Button>
            <Button variant="outline" size="icon" className="bg-black/30"><MessageCircle className="h-5 w-5" /></Button>
            <Button variant="outline" size="icon" className="bg-black/30"><Share2 className="h-5 w-5" /></Button>
          </div>
        </motion.article>
      ))}
    </section>
  );
}
