import { ArrowUpRight, BadgeCheck, TrendingDown, TrendingUp } from "lucide-react";
import type { Property } from "@/types/property";
import { formatCurrency } from "@/lib/utils";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";

export function ValuationPanel({ property }: { property: Property }) {
  const TrendIcon = property.ai_valuation.trend === "down" ? TrendingDown : TrendingUp;
  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2"><BadgeCheck className="h-5 w-5 text-aris-champagne" /> AI valuation</CardTitle>
      </CardHeader>
      <CardContent className="space-y-5">
        <div className="grid gap-3 sm:grid-cols-3">
          <div className="rounded-3xl bg-white/[0.05] p-4">
            <p className="text-xs text-muted-foreground">Estimate</p>
            <p className="mt-1 text-2xl font-semibold">{formatCurrency(property.ai_valuation.estimate)}</p>
          </div>
          <div className="rounded-3xl bg-white/[0.05] p-4">
            <p className="text-xs text-muted-foreground">Confidence</p>
            <p className="mt-1 text-2xl font-semibold">{property.ai_valuation.confidence}%</p>
          </div>
          <div className="rounded-3xl bg-white/[0.05] p-4">
            <p className="text-xs text-muted-foreground">Trend</p>
            <p className="mt-1 flex items-center gap-2 text-2xl font-semibold capitalize"><TrendIcon className="h-5 w-5 text-aris-champagne" /> {property.ai_valuation.trend}</p>
          </div>
        </div>
        <p className="text-sm leading-6 text-muted-foreground">{property.ai_valuation.rationale}</p>
        <div className="space-y-2">
          <p className="text-sm font-medium">Comparable homes</p>
          {property.ai_valuation.comps.map((comp) => (
            <div key={comp.address} className="flex items-center justify-between rounded-2xl border border-white/10 bg-white/[0.03] p-3 text-sm">
              <div>
                <p className="font-medium">{comp.address}</p>
                <p className="text-muted-foreground">{comp.beds} bd · {comp.baths} ba · {comp.sqft.toLocaleString()} ft² · {comp.distanceMiles} mi</p>
              </div>
              <p className="flex items-center gap-1 font-semibold">{formatCurrency(comp.price)} <ArrowUpRight className="h-4 w-4 text-muted-foreground" /></p>
            </div>
          ))}
        </div>
      </CardContent>
    </Card>
  );
}
