import type { Property } from "@/types/property";
import { PropertyCard } from "@/components/property/property-card";

export function PropertyGrid({ properties }: { properties: Property[] }) {
  return (
    <div className="grid gap-6 md:grid-cols-2 xl:grid-cols-3">
      {properties.map((property, index) => <PropertyCard key={property.id} property={property} priority={index < 2} />)}
    </div>
  );
}
