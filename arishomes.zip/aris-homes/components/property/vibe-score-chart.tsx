"use client";

import { PolarAngleAxis, PolarGrid, Radar, RadarChart, ResponsiveContainer, Tooltip } from "recharts";
import type { VibeScores } from "@/types/property";

export function VibeScoreChart({ scores }: { scores: VibeScores }) {
  const data = [
    { vibe: "Luxury", score: scores.luxury },
    { vibe: "Calm", score: scores.calm },
    { vibe: "Family", score: scores.family },
    { vibe: "Nightlife", score: scores.nightlife },
    { vibe: "Nature", score: scores.nature },
    { vibe: "Creative", score: scores.creative }
  ];
  return (
    <div className="h-[300px] w-full">
      <ResponsiveContainer width="100%" height="100%">
        <RadarChart data={data} outerRadius="76%">
          <PolarGrid stroke="rgba(255,255,255,0.12)" />
          <PolarAngleAxis dataKey="vibe" tick={{ fill: "rgba(255,255,255,0.70)", fontSize: 12 }} />
          <Radar dataKey="score" stroke="#f2d6a2" fill="#f2d6a2" fillOpacity={0.32} />
          <Tooltip contentStyle={{ background: "#111018", border: "1px solid rgba(255,255,255,.12)", borderRadius: 16 }} />
        </RadarChart>
      </ResponsiveContainer>
    </div>
  );
}
