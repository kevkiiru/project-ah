"use client";

import Image from "next/image";
import { useState } from "react";
import { Maximize2, WandSparkles } from "lucide-react";
import type { Property } from "@/types/property";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogTrigger } from "@/components/ui/dialog";

export function PropertyGallery({ property }: { property: Property }) {
  const [staged, setStaged] = useState(false);
  const hero = property.images[0];
  const secondary = property.images.slice(1, 3);

  return (
    <div className="relative grid gap-3 overflow-hidden rounded-[2.5rem] lg:grid-cols-[2fr_1fr]">
      <div className="relative aspect-[16/10] overflow-hidden bg-muted lg:aspect-[16/11]">
        <Image src={hero.url} alt={hero.alt} fill priority sizes="(max-width: 1024px) 100vw, 66vw" className="object-cover" />
        <div className="absolute inset-0 bg-gradient-to-t from-black/45 to-transparent" />
        {staged && (
          <div className="absolute inset-x-5 top-5 rounded-2xl border border-aris-champagne/30 bg-black/45 px-4 py-3 text-sm text-aris-champagne backdrop-blur">
            AI virtual staging preview enabled — modern luxe furniture set, warmer lighting, curated art.
          </div>
        )}
      </div>
      <div className="grid grid-cols-2 gap-3 lg:grid-cols-1">
        {secondary.map((img) => (
          <div key={img.id} className="relative aspect-[16/10] overflow-hidden bg-muted">
            <Image src={img.url} alt={img.alt} fill sizes="(max-width: 1024px) 50vw, 33vw" className="object-cover" />
          </div>
        ))}
      </div>
      <div className="absolute bottom-5 right-5 flex gap-2">
        <Button variant="outline" onClick={() => setStaged((value) => !value)} className="bg-black/35 backdrop-blur">
          <WandSparkles className="mr-2 h-4 w-4" /> {staged ? "Original" : "AI Stage"}
        </Button>
        <Dialog>
          <DialogTrigger asChild>
            <Button variant="luxury"><Maximize2 className="mr-2 h-4 w-4" /> Gallery</Button>
          </DialogTrigger>
          <DialogContent className="max-w-5xl">
            <div className="grid gap-3 md:grid-cols-2">
              {property.images.map((img) => (
                <div key={img.id} className="relative aspect-[4/3] overflow-hidden rounded-3xl bg-muted">
                  <Image src={img.url} alt={img.alt} fill sizes="50vw" className="object-cover" />
                </div>
              ))}
            </div>
          </DialogContent>
        </Dialog>
      </div>
    </div>
  );
}
