import Image from "next/image";
import Link from "next/link";
import { Bath, BedDouble, Heart, MapPin, Ruler, Sparkles } from "lucide-react";
import type { Property } from "@/types/property";
import { formatCurrency } from "@/lib/utils";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";

export function PropertyCard({ property, priority = false }: { property: Property; priority?: boolean }) {
  return (
    <article className="group overflow-hidden rounded-[2rem] border border-white/10 bg-white/[0.05] shadow-luxe backdrop-blur-xl transition hover:-translate-y-1 hover:bg-white/[0.08]">
      <Link href={`/property/${property.id}`} className="block">
        <div className="relative aspect-[4/3] overflow-hidden bg-muted">
          <Image
            src={property.images[0]?.url}
            alt={property.title}
            fill
            priority={priority}
            className="object-cover transition duration-700 group-hover:scale-105"
            sizes="(max-width: 768px) 100vw, 33vw"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/5 to-transparent" />
          <div className="absolute left-4 top-4 flex gap-2">
            {property.vibe_tags.slice(0, 2).map((tag) => <Badge key={tag} variant="vibe">{tag}</Badge>)}
          </div>
          <Button variant="outline" size="icon" className="absolute right-4 top-4 bg-black/30" aria-label="Save property">
            <Heart className="h-4 w-4" />
          </Button>
          <div className="absolute bottom-4 left-4 right-4">
            <p className="text-2xl font-semibold">{formatCurrency(property.price)}</p>
            <p className="mt-1 flex items-center gap-1 text-sm text-white/78"><MapPin className="h-4 w-4" /> {property.neighborhood}, {property.city}</p>
          </div>
        </div>
      </Link>
      <div className="space-y-4 p-5">
        <div>
          <Link href={`/property/${property.id}`} className="text-xl font-semibold tracking-tight hover:text-aris-champagne">{property.title}</Link>
          <p className="mt-2 line-clamp-2 text-sm text-muted-foreground">{property.ai_description}</p>
        </div>
        <div className="grid grid-cols-3 gap-2 text-sm text-muted-foreground">
          <span className="flex items-center gap-2"><BedDouble className="h-4 w-4 text-foreground" /> {property.beds} beds</span>
          <span className="flex items-center gap-2"><Bath className="h-4 w-4 text-foreground" /> {property.baths} baths</span>
          <span className="flex items-center gap-2"><Ruler className="h-4 w-4 text-foreground" /> {property.sqft.toLocaleString()} ft²</span>
        </div>
        <div className="flex items-center justify-between border-t border-white/10 pt-4 text-sm">
          <span className="flex items-center gap-2 text-aris-champagne"><Sparkles className="h-4 w-4" /> {property.ai_valuation.confidence}% AI confidence</span>
          <Link href={`/property/${property.id}`} className="font-medium text-foreground hover:text-aris-champagne">View details</Link>
        </div>
      </div>
    </article>
  );
}
