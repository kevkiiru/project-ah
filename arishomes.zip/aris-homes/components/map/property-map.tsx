"use client";

import { useEffect, useRef } from "react";
import mapboxgl from "mapbox-gl";
import "mapbox-gl/dist/mapbox-gl.css";
import type { Property } from "@/types/property";
import { formatCurrency } from "@/lib/utils";

export function PropertyMap({ properties }: { properties: Property[] }) {
  const mapRef = useRef<HTMLDivElement>(null);
  const token = process.env.NEXT_PUBLIC_MAPBOX_TOKEN;

  useEffect(() => {
    if (!mapRef.current || !token) return;
    mapboxgl.accessToken = token;
    const map = new mapboxgl.Map({
      container: mapRef.current,
      style: "mapbox://styles/mapbox/dark-v11",
      center: [-97.78, 30.27],
      zoom: 10.5
    });
    map.addControl(new mapboxgl.NavigationControl({ showCompass: false }), "top-right");
    properties.forEach((property) => {
      const marker = document.createElement("button");
      marker.className = "rounded-full bg-[#f2d6a2] px-3 py-1 text-xs font-bold text-[#07070a] shadow-lg";
      marker.innerText = formatCurrency(property.price, 0).replace("$", "$ ");
      new mapboxgl.Marker(marker)
        .setLngLat([property.lng, property.lat])
        .setPopup(new mapboxgl.Popup({ offset: 16 }).setHTML(`<strong>${property.title}</strong><br/>${property.neighborhood}<br/>${formatCurrency(property.price)}`))
        .addTo(map);
    });
    return () => map.remove();
  }, [properties, token]);

  if (!token) {
    return (
      <div className="relative min-h-[640px] overflow-hidden rounded-[2.5rem] border border-white/10 bg-[radial-gradient(circle_at_20%_20%,rgba(242,214,162,.16),transparent_20%),radial-gradient(circle_at_70%_40%,rgba(152,184,216,.14),transparent_24%),linear-gradient(135deg,#111018,#07070a)] shadow-luxe">
        <div className="absolute inset-0 opacity-20" style={{ backgroundImage: "linear-gradient(rgba(255,255,255,.08) 1px, transparent 1px), linear-gradient(90deg, rgba(255,255,255,.08) 1px, transparent 1px)", backgroundSize: "48px 48px" }} />
        {properties.map((property, index) => (
          <div key={property.id} className="absolute rounded-full border border-black/20 bg-aris-champagne px-3 py-1 text-xs font-bold text-aris-ink shadow-glow" style={{ left: `${24 + index * 24}%`, top: `${28 + (index % 2) * 24}%` }}>
            {formatCurrency(property.price)} · {property.vibe_tags[0]}
          </div>
        ))}
        <div className="absolute bottom-6 left-6 right-6 rounded-3xl border border-white/10 bg-black/40 p-5 backdrop-blur">
          <p className="font-semibold">Mapbox token not configured</p>
          <p className="mt-1 text-sm text-muted-foreground">Set NEXT_PUBLIC_MAPBOX_TOKEN for live clusters, markers, and vibe heatmaps. This demo keeps the map layout visible.</p>
        </div>
      </div>
    );
  }

  return <div ref={mapRef} className="min-h-[640px] overflow-hidden rounded-[2.5rem] border border-white/10 shadow-luxe" />;
}
