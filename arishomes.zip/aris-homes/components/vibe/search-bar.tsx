"use client";

import { FormEvent, useState } from "react";
import { Search, Sparkles, SlidersHorizontal } from "lucide-react";
import { useRouter } from "next/navigation";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { useSearchStore } from "@/stores/search-store";

export function NaturalLanguageSearch({ compact = false }: { compact?: boolean }) {
  const router = useRouter();
  const { query, setQuery } = useSearchStore();
  const [loading, setLoading] = useState(false);

  async function onSubmit(event: FormEvent) {
    event.preventDefault();
    setLoading(true);
    const params = new URLSearchParams();
    if (query) params.set("q", query);
    router.push(`/search?${params.toString()}`);
    setLoading(false);
  }

  return (
    <form onSubmit={onSubmit} className="glass flex w-full flex-col gap-3 rounded-[2rem] p-3 md:flex-row md:items-center">
      <div className="flex flex-1 items-center gap-3 px-2">
        <Search className="h-5 w-5 text-aris-champagne" />
        <Input
          value={query}
          onChange={(event) => setQuery(event.target.value)}
          className="border-0 bg-transparent px-0 shadow-none focus-visible:ring-0"
          placeholder={compact ? "Describe your dream home..." : "Modern 3 bedroom with pool under $800k in Austin near great schools"}
        />
      </div>
      <div className="flex gap-2">
        <Button type="button" variant="outline" className="flex-1 md:flex-none">
          <SlidersHorizontal className="mr-2 h-4 w-4" /> Vibes
        </Button>
        <Button type="submit" variant="luxury" className="flex-1 md:flex-none" disabled={loading}>
          <Sparkles className="mr-2 h-4 w-4" /> AI Search
        </Button>
      </div>
    </form>
  );
}
