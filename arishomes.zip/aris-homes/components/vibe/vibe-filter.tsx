"use client";

import { motion } from "framer-motion";
import { vibeTags } from "@/lib/sample-data";
import type { VibeTag } from "@/types/property";
import { cn } from "@/lib/utils";

type Props = {
  selected?: VibeTag[];
  onToggle?: (tag: VibeTag) => void;
};

export function VibeFilter({ selected = [], onToggle }: Props) {
  return (
    <div className="flex flex-wrap gap-2">
      {vibeTags.map((tag) => {
        const active = selected.includes(tag);
        return (
          <motion.button
            key={tag}
            whileTap={{ scale: 0.96 }}
            onClick={() => onToggle?.(tag)}
            className={cn(
              "rounded-full border px-4 py-2 text-sm transition",
              active
                ? "border-aris-champagne bg-aris-champagne text-aris-ink shadow-glow"
                : "border-white/10 bg-white/[0.04] text-muted-foreground hover:bg-white/[0.08] hover:text-foreground"
            )}
          >
            {tag}
          </motion.button>
        );
      })}
    </div>
  );
}
