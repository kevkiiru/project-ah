import Link from "next/link";
import { Home, LayoutDashboard, Map, MessageCircle, Search, Sparkles, UserRound } from "lucide-react";
import { AIConcierge } from "@/components/ai/ai-concierge";
import { Button } from "@/components/ui/button";

const nav = [
  { href: "/", label: "Vibe Feed", icon: Home },
  { href: "/search", label: "Search", icon: Search },
  { href: "/matches", label: "Matches", icon: Sparkles },
  { href: "/map", label: "Map", icon: Map },
  { href: "/dashboard", label: "Dashboard", icon: LayoutDashboard }
];

export function AppShell({ children }: { children: React.ReactNode }) {
  return (
    <div className="min-h-screen noise">
      <header className="sticky top-0 z-40 border-b border-white/10 bg-background/72 backdrop-blur-2xl">
        <div className="container flex h-20 items-center justify-between gap-4">
          <Link href="/" className="group flex items-center gap-3">
            <div className="flex h-11 w-11 items-center justify-center rounded-2xl bg-gradient-to-br from-aris-champagne to-aris-sky text-aris-ink shadow-glow">
              <Sparkles className="h-5 w-5" />
            </div>
            <div>
              <p className="font-display text-2xl font-semibold leading-none tracking-tight">Aris</p>
              <p className="text-xs text-muted-foreground">Find your vibe.</p>
            </div>
          </Link>

          <nav className="hidden items-center rounded-full border border-white/10 bg-white/[0.04] p-1 lg:flex">
            {nav.map((item) => {
              const Icon = item.icon;
              return (
                <Link key={item.href} href={item.href} className="flex items-center gap-2 rounded-full px-4 py-2 text-sm text-muted-foreground transition hover:bg-white/10 hover:text-foreground">
                  <Icon className="h-4 w-4" />
                  {item.label}
                </Link>
              );
            })}
          </nav>

          <div className="flex items-center gap-2">
            <Button asChild variant="ghost" className="hidden md:inline-flex">
              <Link href="/listing-studio"><MessageCircle className="mr-2 h-4 w-4" /> List with AI</Link>
            </Button>
            <Button asChild variant="outline" size="icon" aria-label="Account">
              <Link href="/login"><UserRound className="h-5 w-5" /></Link>
            </Button>
          </div>
        </div>
      </header>

      <main>{children}</main>

      <nav className="fixed bottom-4 left-1/2 z-40 flex -translate-x-1/2 items-center gap-1 rounded-full border border-white/10 bg-background/75 p-1 shadow-luxe backdrop-blur-2xl lg:hidden">
        {nav.slice(0, 5).map((item) => {
          const Icon = item.icon;
          return (
            <Link key={item.href} href={item.href} className="flex h-12 w-12 items-center justify-center rounded-full text-muted-foreground transition hover:bg-white/10 hover:text-foreground" aria-label={item.label}>
              <Icon className="h-5 w-5" />
            </Link>
          );
        })}
      </nav>

      <AIConcierge />
    </div>
  );
}
