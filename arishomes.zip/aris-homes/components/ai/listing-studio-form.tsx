"use client";

import { useState } from "react";
import { useForm } from "react-hook-form";
import { z } from "zod";
import { zodResolver } from "@hookform/resolvers/zod";
import { Loader2, Sparkles, UploadCloud } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";

const ListingSchema = z.object({
  address: z.string().min(4, "Enter an address"),
  beds: z.coerce.number().min(0),
  baths: z.coerce.number().min(0),
  sqft: z.coerce.number().min(100),
  notes: z.string().min(20, "Add more notes so AI has signal")
});

type ListingInput = z.input<typeof ListingSchema>;
type ListingForm = z.output<typeof ListingSchema>;
type ListingOutput = {
  title: string;
  description: string;
  priceSuggestion: string;
  vibeTags: string[];
  seoKeywords: string[];
  socialCaption: string;
  buyerPersona: string;
};

export function ListingStudioForm() {
  const [result, setResult] = useState<ListingOutput | null>(null);
  const [loading, setLoading] = useState(false);
  const form = useForm<ListingInput, unknown, ListingForm>({
    resolver: zodResolver(ListingSchema),
    defaultValues: { address: "", beds: 3, baths: 2, sqft: 2100, notes: "" }
  });

  async function onSubmit(values: ListingForm) {
    setLoading(true);
    const response = await fetch("/api/ai/listing-studio", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(values)
    });
    setResult(await response.json());
    setLoading(false);
  }

  return (
    <div className="grid gap-6 lg:grid-cols-[0.9fr_1.1fr]">
      <Card>
        <CardHeader>
          <CardTitle>Seller Listing Studio</CardTitle>
        </CardHeader>
        <CardContent>
          <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
            <div className="grid gap-4 md:grid-cols-2">
              <div className="md:col-span-2">
                <label className="mb-2 block text-sm text-muted-foreground">Address</label>
                <Input {...form.register("address")} placeholder="2408 Scenic Dr, Austin, TX" />
              </div>
              <div>
                <label className="mb-2 block text-sm text-muted-foreground">Beds</label>
                <Input type="number" {...form.register("beds")} />
              </div>
              <div>
                <label className="mb-2 block text-sm text-muted-foreground">Baths</label>
                <Input type="number" step="0.5" {...form.register("baths")} />
              </div>
              <div className="md:col-span-2">
                <label className="mb-2 block text-sm text-muted-foreground">Square feet</label>
                <Input type="number" {...form.register("sqft")} />
              </div>
            </div>
            <div className="rounded-[2rem] border border-dashed border-white/15 bg-white/[0.03] p-6 text-center">
              <UploadCloud className="mx-auto h-8 w-8 text-aris-champagne" />
              <p className="mt-2 font-medium">Upload listing photos</p>
              <p className="mt-1 text-xs text-muted-foreground">Connect Supabase Storage to enable real uploads; this UI is ready for it.</p>
            </div>
            <div>
              <label className="mb-2 block text-sm text-muted-foreground">Seller notes, upgrades, vibe</label>
              <Textarea {...form.register("notes")} placeholder="Renovated kitchen, oak floors, pool, great schools, quiet street, warm modern style..." />
              {form.formState.errors.notes && <p className="mt-2 text-xs text-destructive">{form.formState.errors.notes.message}</p>}
            </div>
            <Button type="submit" variant="luxury" size="lg" disabled={loading} className="w-full">
              {loading ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : <Sparkles className="mr-2 h-4 w-4" />} Generate premium listing
            </Button>
          </form>
        </CardContent>
      </Card>

      <Card className="min-h-[600px]">
        <CardHeader>
          <CardTitle>AI output</CardTitle>
        </CardHeader>
        <CardContent>
          {!result ? (
            <div className="flex min-h-[450px] items-center justify-center rounded-[2rem] border border-white/10 bg-white/[0.03] p-8 text-center text-muted-foreground">
              Add property facts and notes to generate title, description, pricing rationale, vibe tags, SEO, and social copy.
            </div>
          ) : (
            <div className="space-y-6">
              <div>
                <p className="text-sm text-aris-champagne">Title</p>
                <h2 className="mt-2 font-display text-4xl">{result.title}</h2>
              </div>
              <div>
                <p className="text-sm text-aris-champagne">Description</p>
                <p className="mt-2 leading-7 text-muted-foreground">{result.description}</p>
              </div>
              <div className="grid gap-4 md:grid-cols-2">
                <div className="rounded-3xl bg-white/[0.04] p-4">
                  <p className="text-sm text-aris-champagne">Pricing</p>
                  <p className="mt-2 text-sm text-muted-foreground">{result.priceSuggestion}</p>
                </div>
                <div className="rounded-3xl bg-white/[0.04] p-4">
                  <p className="text-sm text-aris-champagne">Buyer persona</p>
                  <p className="mt-2 text-sm text-muted-foreground">{result.buyerPersona}</p>
                </div>
              </div>
              <div className="flex flex-wrap gap-2">{result.vibeTags.map((tag) => <Badge key={tag} variant="vibe">{tag}</Badge>)}</div>
              <div>
                <p className="text-sm text-aris-champagne">Social caption</p>
                <p className="mt-2 rounded-3xl bg-white/[0.04] p-4 text-sm text-muted-foreground">{result.socialCaption}</p>
              </div>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
