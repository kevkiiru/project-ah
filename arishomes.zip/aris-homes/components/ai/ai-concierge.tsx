"use client";

import { FormEvent, useState } from "react";
import { Bot, Loader2, MessageCircle, Send, Sparkles, X } from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";

type ChatMessage = { role: "user" | "assistant"; content: string };

export function AIConcierge() {
  const [open, setOpen] = useState(false);
  const [input, setInput] = useState("");
  const [messages, setMessages] = useState<ChatMessage[]>([
    { role: "assistant", content: "Hi, I’m Aris. Tell me the lifestyle, neighborhood, budget, or photo vibe you want — I’ll translate it into homes." }
  ]);
  const [loading, setLoading] = useState(false);

  async function send(event: FormEvent) {
    event.preventDefault();
    if (!input.trim() || loading) return;
    const userMessage: ChatMessage = { role: "user", content: input.trim() };
    setMessages((current) => [...current, userMessage]);
    setInput("");
    setLoading(true);
    try {
      const response = await fetch("/api/ai/chat", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ messages: [...messages, userMessage] })
      });
      const data = await response.json();
      setMessages((current) => [...current, { role: "assistant", content: data.answer ?? "I found a few promising directions. Want me to filter by commute, schools, or design vibe next?" }]);
    } catch {
      setMessages((current) => [...current, { role: "assistant", content: "I’m in demo mode right now. Try: ‘Find calm luxury homes under $850k with room to host.’" }]);
    } finally {
      setLoading(false);
    }
  }

  return (
    <>
      <Button variant="luxury" size="icon" className="fixed bottom-24 right-5 z-50 h-14 w-14 shadow-glow lg:bottom-8" onClick={() => setOpen(true)} aria-label="Open Aris AI Concierge">
        <MessageCircle className="h-6 w-6" />
      </Button>
      <AnimatePresence>
        {open && (
          <motion.aside
            initial={{ opacity: 0, y: 30, scale: 0.96 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: 20, scale: 0.96 }}
            className="fixed bottom-24 right-4 z-50 flex h-[620px] max-h-[calc(100vh-8rem)] w-[calc(100vw-2rem)] max-w-md flex-col overflow-hidden rounded-[2rem] border border-white/10 bg-background/95 shadow-luxe backdrop-blur-2xl lg:bottom-8"
          >
            <div className="flex items-center justify-between border-b border-white/10 p-4">
              <div className="flex items-center gap-3">
                <div className="flex h-10 w-10 items-center justify-center rounded-2xl bg-aris-champagne text-aris-ink"><Bot className="h-5 w-5" /></div>
                <div>
                  <p className="font-semibold">Aris AI Concierge</p>
                  <p className="text-xs text-muted-foreground">Search · offers · insights</p>
                </div>
              </div>
              <Button variant="ghost" size="icon" onClick={() => setOpen(false)}><X className="h-4 w-4" /></Button>
            </div>
            <div className="flex-1 space-y-3 overflow-y-auto p-4">
              {messages.map((message, index) => (
                <div key={`${message.role}-${index}`} className={message.role === "user" ? "ml-auto max-w-[82%] rounded-3xl bg-primary px-4 py-3 text-sm text-primary-foreground" : "mr-auto max-w-[86%] rounded-3xl bg-white/[0.07] px-4 py-3 text-sm text-muted-foreground"}>
                  {message.content}
                </div>
              ))}
              {loading && <div className="mr-auto flex max-w-[86%] items-center gap-2 rounded-3xl bg-white/[0.07] px-4 py-3 text-sm text-muted-foreground"><Loader2 className="h-4 w-4 animate-spin" /> Thinking through the vibe...</div>}
            </div>
            <div className="border-t border-white/10 p-3">
              <div className="mb-2 flex gap-2 overflow-x-auto pb-1 text-xs text-muted-foreground">
                {['Find hidden gems', 'Draft an offer', 'Compare neighborhoods'].map((chip) => <button key={chip} onClick={() => setInput(chip)} className="rounded-full border border-white/10 px-3 py-1 hover:bg-white/10"><Sparkles className="mr-1 inline h-3 w-3" />{chip}</button>)}
              </div>
              <form onSubmit={send} className="flex gap-2">
                <Input value={input} onChange={(event) => setInput(event.target.value)} placeholder="Ask Aris anything..." />
                <Button type="submit" variant="luxury" size="icon"><Send className="h-4 w-4" /></Button>
              </form>
            </div>
          </motion.aside>
        )}
      </AnimatePresence>
    </>
  );
}
