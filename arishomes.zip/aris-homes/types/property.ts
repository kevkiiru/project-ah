export type UserRole = "buyer" | "seller" | "agent";
export type PropertyStatus = "draft" | "active" | "pending" | "sold" | "archived";

export type VibeTag =
  | "Minimalist"
  | "Bohemian"
  | "Luxury"
  | "Cozy"
  | "Industrial"
  | "Family-Friendly"
  | "Waterfront"
  | "Urban"
  | "Nature"
  | "Smart Home"
  | "Entertainer"
  | "Historic"
  | "Creative";

export interface PropertyImage {
  id: string;
  property_id: string;
  url: string;
  alt: string;
  sort_order: number;
  is_hero?: boolean;
}

export interface VibeScores {
  luxury: number;
  calm: number;
  family: number;
  nightlife: number;
  nature: number;
  creative: number;
}

export interface ComparableProperty {
  address: string;
  price: number;
  beds: number;
  baths: number;
  sqft: number;
  distanceMiles: number;
}

export interface Property {
  id: string;
  title: string;
  description: string;
  price: number;
  location: string;
  neighborhood: string;
  city: string;
  state: string;
  beds: number;
  baths: number;
  sqft: number;
  lat: number;
  lng: number;
  vibe_tags: VibeTag[];
  ai_description: string;
  ai_valuation: {
    estimate: number;
    confidence: number;
    trend: "up" | "flat" | "down";
    rationale: string;
    comps: ComparableProperty[];
  };
  vibe_scores: VibeScores;
  status: PropertyStatus;
  images: PropertyImage[];
  agent: {
    name: string;
    avatar: string;
    responseTime: string;
  };
  created_at: string;
}
