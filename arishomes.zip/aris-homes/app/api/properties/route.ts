import { properties } from "@/lib/sample-data";
import { createSupabaseServerClient, isSupabaseConfigured } from "@/lib/supabase";

export async function GET() {
  if (!isSupabaseConfigured()) return Response.json(properties);
  const supabase = await createSupabaseServerClient();
  const { data, error } = await supabase
    .from("properties")
    .select("*, property_images(*)")
    .eq("status", "active")
    .order("created_at", { ascending: false });
  if (error) return Response.json(properties);
  return Response.json(data);
}

export async function POST(request: Request) {
  if (!isSupabaseConfigured()) return Response.json({ message: "Supabase not configured. Listing accepted in demo mode." }, { status: 202 });
  const supabase = await createSupabaseServerClient();
  const body = await request.json();
  const { data, error } = await supabase.from("properties").insert(body).select().single();
  if (error) return Response.json({ error: error.message }, { status: 400 });
  return Response.json(data, { status: 201 });
}
