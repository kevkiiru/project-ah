import { generateObject } from "ai";
import { z } from "zod";
import { getAIModel } from "@/lib/ai";
import { properties } from "@/lib/sample-data";

const SearchIntentSchema = z.object({
  city: z.string().optional(),
  maxPrice: z.number().optional(),
  minBeds: z.number().optional(),
  vibes: z.array(z.string()).default([]),
  rationale: z.string()
});

export async function POST(request: Request) {
  const { query = "" } = await request.json();
  if (!process.env.OPENAI_API_KEY && !process.env.ANTHROPIC_API_KEY) {
    const lowered = String(query).toLowerCase();
    const filtered = properties.filter((property) => {
      const priceOk = lowered.includes("800") ? property.price < 800000 : true;
      const poolOrNature = lowered.includes("pool") || lowered.includes("nature") ? property.vibe_tags.some((tag) => ["Luxury", "Nature", "Entertainer"].includes(tag)) : true;
      return priceOk && poolOrNature;
    });
    return Response.json({ intent: { vibes: ["Luxury", "Family-Friendly"], rationale: "Demo parser matched price and lifestyle cues." }, results: filtered });
  }
  const result = await generateObject({
    model: getAIModel(),
    schema: SearchIntentSchema,
    prompt: `Extract structured real estate search intent from: ${query}`
  });
  return Response.json({ intent: result.object, results: properties });
}
