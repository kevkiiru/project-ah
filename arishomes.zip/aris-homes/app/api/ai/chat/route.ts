import { generateText } from "ai";
import { arisSystemPrompt, getAIModel } from "@/lib/ai";
import { properties } from "@/lib/sample-data";

export async function POST(request: Request) {
  const { messages = [] } = await request.json();
  const latest = messages.at(-1)?.content ?? "";

  if (!process.env.OPENAI_API_KEY && !process.env.ANTHROPIC_API_KEY) {
    return Response.json({
      answer: `Demo insight: based on “${latest}”, I’d start with ${properties[0].title} for calm luxury and ${properties[2].title} for family/nature energy. Add budget, commute, and must-have vibe tags so I can narrow this like a concierge.`
    });
  }

  const result = await generateText({
    model: getAIModel(),
    system: `${arisSystemPrompt}\nAvailable demo listings: ${properties.map((p) => `${p.title} in ${p.neighborhood}, ${p.city}, $${p.price}, vibes: ${p.vibe_tags.join(", ")}`).join(" | ")}`,
    messages: messages.map((message: { role: "user" | "assistant"; content: string }) => ({ role: message.role, content: message.content })),
    temperature: 0.6
  });

  return Response.json({ answer: result.text });
}
