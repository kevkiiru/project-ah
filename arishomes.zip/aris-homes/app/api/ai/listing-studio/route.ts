import { generateObject } from "ai";
import { z } from "zod";
import { getAIModel, listingStudioPrompt } from "@/lib/ai";

const ListingOutput = z.object({
  title: z.string(),
  description: z.string(),
  priceSuggestion: z.string(),
  vibeTags: z.array(z.string()),
  seoKeywords: z.array(z.string()),
  socialCaption: z.string(),
  buyerPersona: z.string()
});

export async function POST(request: Request) {
  const body = await request.json();
  if (!process.env.OPENAI_API_KEY && !process.env.ANTHROPIC_API_KEY) {
    return Response.json({
      title: "Warm Modern Retreat with Effortless Indoor-Outdoor Flow",
      description: `A polished Aris-ready listing based on your notes: ${body.notes ?? "bright spaces, thoughtful upgrades, and a calm premium vibe"}. This home blends daily comfort with memorable moments for hosting, working, and unwinding.`,
      priceSuggestion: "Price near the top quartile of recent comps if photography and staging are premium; validate with local agent CMA.",
      vibeTags: ["Luxury", "Cozy", "Family-Friendly", "Entertainer"],
      seoKeywords: ["modern home", "move-in ready", "luxury real estate", "outdoor living"],
      socialCaption: "Not just a listing — a whole mood. Warm light, elevated finishes, and spaces made for the life you’re building.",
      buyerPersona: "Design-aware buyer who values comfort, hosting, and turnkey convenience."
    });
  }

  const result = await generateObject({
    model: getAIModel(),
    schema: ListingOutput,
    system: listingStudioPrompt,
    prompt: JSON.stringify(body)
  });
  return Response.json(result.object);
}
