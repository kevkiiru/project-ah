import Link from "next/link";
import { KeyRound, Mail, Sparkles } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";

export default function LoginPage() {
  return (
    <section className="container grid min-h-[calc(100vh-5rem)] place-items-center py-10">
      <Card className="w-full max-w-md">
        <CardHeader className="text-center">
          <div className="mx-auto flex h-12 w-12 items-center justify-center rounded-2xl bg-aris-champagne text-aris-ink"><Sparkles className="h-5 w-5" /></div>
          <CardTitle className="mt-4 font-display text-4xl">Welcome to Aris</CardTitle>
          <p className="text-sm text-muted-foreground">Sign in with Supabase email magic link or Google OAuth.</p>
        </CardHeader>
        <CardContent className="space-y-4">
          <Button variant="outline" size="lg" className="w-full"><KeyRound className="mr-2 h-4 w-4" /> Continue with Google</Button>
          <div className="relative text-center text-xs text-muted-foreground"><span className="bg-card px-3">or email</span><div className="absolute left-0 right-0 top-1/2 -z-0 h-px bg-white/10" /></div>
          <Input type="email" placeholder="you@example.com" />
          <Button variant="luxury" size="lg" className="w-full"><Mail className="mr-2 h-4 w-4" /> Send magic link</Button>
          <p className="text-center text-xs text-muted-foreground">Demo UI. Wire the actions to <code>createSupabaseBrowserClient()</code> once env keys are set.</p>
          <Button asChild variant="ghost" className="w-full"><Link href="/onboarding">Continue to onboarding demo</Link></Button>
        </CardContent>
      </Card>
    </section>
  );
}
