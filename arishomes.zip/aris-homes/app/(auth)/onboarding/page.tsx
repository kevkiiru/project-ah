import Link from "next/link";
import { BriefcaseBusiness, Heart, Home, Sparkles } from "lucide-react";
import { vibeTags } from "@/lib/sample-data";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent } from "@/components/ui/card";

export default function OnboardingPage() {
  const roles = [
    { label: "Buyer", icon: Heart, body: "Get personalized matches and saved search alerts." },
    { label: "Seller", icon: Home, body: "Create standout listings and track buyer interest." },
    { label: "Agent", icon: BriefcaseBusiness, body: "Manage leads, listings, and AI-assisted conversations." }
  ];
  return (
    <section className="container space-y-8 py-10">
      <div className="max-w-4xl">
        <Badge variant="vibe"><Sparkles className="mr-2 h-3.5 w-3.5" /> First login quiz</Badge>
        <h1 className="mt-4 font-display text-5xl md:text-7xl">Let’s tune Aris to your lifestyle.</h1>
        <p className="mt-4 text-muted-foreground">Choose your role and vibe preferences. In production this persists to the <code>profiles</code> table.</p>
      </div>
      <div className="grid gap-4 md:grid-cols-3">
        {roles.map((role) => {
          const Icon = role.icon;
          return <Card key={role.label} className="cursor-pointer transition hover:-translate-y-1 hover:border-aris-champagne/30"><CardContent className="p-6"><Icon className="h-7 w-7 text-aris-champagne" /><h2 className="mt-5 text-2xl font-semibold">{role.label}</h2><p className="mt-2 text-sm text-muted-foreground">{role.body}</p></CardContent></Card>;
        })}
      </div>
      <div className="rounded-[2rem] border border-white/10 bg-white/[0.04] p-6">
        <p className="mb-4 font-semibold">Pick your vibe tags</p>
        <div className="flex flex-wrap gap-2">{vibeTags.map((tag) => <Badge key={tag} variant="outline" className="px-4 py-2">{tag}</Badge>)}</div>
      </div>
      <Button asChild variant="luxury" size="lg"><Link href="/dashboard">Finish onboarding</Link></Button>
    </section>
  );
}
