import type { Metadata, Viewport } from "next";
import "./globals.css";
import { Providers } from "@/components/layout/providers";
import { AppShell } from "@/components/layout/app-shell";
import { Toaster } from "sonner";

export const metadata: Metadata = {
  title: {
    default: "Aris Homes — Find your vibe, not just a house.",
    template: "%s | Aris Homes"
  },
  description: "A vibe-first, AI-powered real estate discovery application for beautiful homes, insights, and conversations.",
  manifest: "/manifest.webmanifest",
  applicationName: "Aris Homes",
  appleWebApp: {
    capable: true,
    title: "Aris Homes",
    statusBarStyle: "black-translucent"
  },
  openGraph: {
    title: "Aris Homes",
    description: "Find your vibe, not just a house.",
    type: "website"
  }
};

export const viewport: Viewport = {
  themeColor: "#07070a",
  width: "device-width",
  initialScale: 1,
  maximumScale: 1
};

export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  return (
    <html lang="en" className="dark" suppressHydrationWarning>
      <body>
        <Providers>
          <AppShell>{children}</AppShell>
          <Toaster richColors position="top-right" theme="dark" />
        </Providers>
      </body>
    </html>
  );
}
