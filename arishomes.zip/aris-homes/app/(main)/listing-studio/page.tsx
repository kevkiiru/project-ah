import { ListingStudioForm } from "@/components/ai/listing-studio-form";

export default function ListingStudioPage() {
  return (
    <section className="container space-y-8 py-10">
      <div className="max-w-4xl">
        <p className="text-sm uppercase tracking-[0.35em] text-aris-champagne">Seller AI</p>
        <h1 className="mt-3 font-display text-5xl md:text-7xl">Turn property facts into a premium listing.</h1>
        <p className="mt-4 text-muted-foreground">Upload-ready workflow for photos, Supabase Storage, AI title/description, valuation notes, vibe tags, SEO keywords, and social content.</p>
      </div>
      <ListingStudioForm />
    </section>
  );
}
