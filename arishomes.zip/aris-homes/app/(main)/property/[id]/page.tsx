import type { Metadata } from "next";
import { CalendarDays, Heart, MessageCircle, Share2, Sparkles } from "lucide-react";
import { getProperty } from "@/lib/sample-data";
import { formatCurrency } from "@/lib/utils";
import { PropertyGallery } from "@/components/property/property-gallery";
import { VibeScoreChart } from "@/components/property/vibe-score-chart";
import { ValuationPanel } from "@/components/property/valuation-panel";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";

export async function generateMetadata({ params }: { params: Promise<{ id: string }> }): Promise<Metadata> {
  const { id } = await params;
  const property = getProperty(id);
  return { title: property.title, description: property.ai_description };
}

export default async function PropertyDetailPage({ params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  const property = getProperty(id);

  return (
    <section className="container space-y-8 py-10">
      <div className="grid gap-6 lg:grid-cols-[1fr_auto] lg:items-end">
        <div>
          <div className="mb-4 flex flex-wrap gap-2">{property.vibe_tags.map((tag) => <Badge key={tag} variant="vibe">{tag}</Badge>)}</div>
          <h1 className="font-display text-5xl leading-none md:text-7xl">{property.title}</h1>
          <p className="mt-4 text-lg text-muted-foreground">{property.location}</p>
        </div>
        <div className="rounded-[2rem] border border-white/10 bg-white/[0.04] p-5 text-right">
          <p className="text-sm text-muted-foreground">Listed at</p>
          <p className="text-4xl font-semibold">{formatCurrency(property.price)}</p>
        </div>
      </div>

      <PropertyGallery property={property} />

      <div className="grid gap-8 lg:grid-cols-[1fr_420px]">
        <div className="space-y-8">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2"><Sparkles className="h-5 w-5 text-aris-champagne" /> AI-generated description</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-lg leading-8 text-muted-foreground">{property.ai_description}</p>
              <p className="mt-6 leading-8 text-muted-foreground">{property.description}</p>
              <div className="mt-6 grid grid-cols-3 gap-3 text-center">
                <div className="rounded-3xl bg-white/[0.04] p-4"><p className="text-2xl font-semibold">{property.beds}</p><p className="text-xs text-muted-foreground">Beds</p></div>
                <div className="rounded-3xl bg-white/[0.04] p-4"><p className="text-2xl font-semibold">{property.baths}</p><p className="text-xs text-muted-foreground">Baths</p></div>
                <div className="rounded-3xl bg-white/[0.04] p-4"><p className="text-2xl font-semibold">{property.sqft.toLocaleString()}</p><p className="text-xs text-muted-foreground">Sq ft</p></div>
              </div>
            </CardContent>
          </Card>

          <ValuationPanel property={property} />
        </div>

        <aside className="space-y-6 lg:sticky lg:top-28 lg:self-start">
          <Card>
            <CardHeader>
              <CardTitle>Visual vibe score</CardTitle>
            </CardHeader>
            <CardContent>
              <VibeScoreChart scores={property.vibe_scores} />
            </CardContent>
          </Card>

          <Card>
            <CardContent className="space-y-4 p-6">
              <div className="flex items-center gap-3">
                <div className="flex h-12 w-12 items-center justify-center rounded-full bg-aris-champagne text-sm font-bold text-aris-ink">{property.agent.avatar}</div>
                <div>
                  <p className="font-semibold">{property.agent.name}</p>
                  <p className="text-xs text-muted-foreground">{property.agent.responseTime}</p>
                </div>
              </div>
              <Button variant="luxury" size="lg" className="w-full"><MessageCircle className="mr-2 h-4 w-4" /> Chat with Owner/Agent</Button>
              <Button variant="outline" size="lg" className="w-full"><CalendarDays className="mr-2 h-4 w-4" /> Schedule viewing</Button>
              <div className="grid grid-cols-2 gap-3">
                <Button variant="outline"><Heart className="mr-2 h-4 w-4" /> Save</Button>
                <Button variant="outline"><Share2 className="mr-2 h-4 w-4" /> Share</Button>
              </div>
            </CardContent>
          </Card>
        </aside>
      </div>
    </section>
  );
}
