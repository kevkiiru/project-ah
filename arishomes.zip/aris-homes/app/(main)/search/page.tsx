import { Suspense } from "react";
import { NaturalLanguageSearch } from "@/components/vibe/search-bar";
import { VibeFilter } from "@/components/vibe/vibe-filter";
import { PropertyGrid } from "@/components/property/property-grid";
import { properties } from "@/lib/sample-data";
import { Badge } from "@/components/ui/badge";

export default async function SearchPage({ searchParams }: { searchParams: Promise<{ q?: string }> }) {
  const params = await searchParams;
  const query = params.q ?? "";
  const lowered = query.toLowerCase();
  const filtered = lowered
    ? properties.filter((property) =>
        `${property.title} ${property.description} ${property.location} ${property.vibe_tags.join(" ")}`.toLowerCase().includes(lowered.split(" ")[0]) ||
        property.price < (lowered.includes("800") ? 800000 : Number.MAX_SAFE_INTEGER)
      )
    : properties;
  return (
    <section className="container space-y-8 py-12">
      <div className="max-w-4xl">
        <Badge variant="vibe">Search</Badge>
        <h1 className="mt-4 font-display text-5xl md:text-7xl">Tell Aris what home feels like.</h1>
        <p className="mt-4 text-muted-foreground">Search supports natural language, vibe tags, location, price, features, and AI interpretation.</p>
      </div>
      <NaturalLanguageSearch />
      <Suspense fallback={null}><VibeFilter /></Suspense>
      {query && <p className="text-sm text-muted-foreground">Showing {filtered.length} AI-ranked results for “{query}”</p>}
      <PropertyGrid properties={filtered.length ? filtered : properties} />
    </section>
  );
}
