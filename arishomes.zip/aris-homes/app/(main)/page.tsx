import Link from "next/link";
import { ArrowRight, Camera, Map, Sparkles, WandSparkles } from "lucide-react";
import { NaturalLanguageSearch } from "@/components/vibe/search-bar";
import { VibeFilter } from "@/components/vibe/vibe-filter";
import { PropertyGrid } from "@/components/property/property-grid";
import { properties } from "@/lib/sample-data";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";

export default function HomePage() {
  return (
    <>
      <section className="container grid min-h-[calc(100vh-5rem)] items-center gap-12 py-14 lg:grid-cols-[1.05fr_0.95fr]">
        <div className="space-y-8">
          <Badge variant="vibe" className="w-fit"><Sparkles className="mr-2 h-3.5 w-3.5" /> AI-powered real estate discovery</Badge>
          <div>
            <h1 className="max-w-5xl font-display text-6xl leading-[0.94] tracking-tight md:text-8xl">
              Find your <span className="premium-gradient-text">vibe</span>, not just a house.
            </h1>
            <p className="mt-6 max-w-2xl text-lg leading-8 text-muted-foreground">
              Aris Homes blends Zillow-scale search with Instagram-style discovery and an AI concierge that understands how you want to live.
            </p>
          </div>
          <NaturalLanguageSearch />
          <div className="space-y-3">
            <p className="text-sm text-muted-foreground">Explore by aesthetic and lifestyle</p>
            <VibeFilter />
          </div>
          <div className="grid max-w-2xl grid-cols-3 gap-3 text-center">
            {[['2.4s', 'avg AI match'], ['94%', 'vibe relevance'], ['24/7', 'AI concierge']].map(([value, label]) => (
              <div key={label} className="rounded-3xl border border-white/10 bg-white/[0.04] p-4">
                <p className="text-2xl font-semibold text-aris-champagne">{value}</p>
                <p className="mt-1 text-xs text-muted-foreground">{label}</p>
              </div>
            ))}
          </div>
        </div>

        <div className="relative hidden lg:block">
          <div className="absolute -inset-12 rounded-full bg-aris-champagne/10 blur-3xl" />
          <div className="relative overflow-hidden rounded-[3rem] border border-white/10 bg-white/[0.04] p-3 shadow-luxe">
            <div className="aspect-[4/5] rounded-[2.4rem] bg-[url('https://images.unsplash.com/photo-1600607687939-ce8a6c25118c?auto=format&fit=crop&w=1200&q=85')] bg-cover bg-center" />
            <div className="absolute bottom-8 left-8 right-8 rounded-[2rem] border border-white/10 bg-black/45 p-5 backdrop-blur-xl">
              <p className="text-sm text-aris-champagne">AI Vibe Match</p>
              <h2 className="mt-2 text-2xl font-semibold">Glass House Above Lake Austin</h2>
              <p className="mt-2 text-sm text-white/72">Minimalist · Luxury · Waterfront · Smart Home</p>
            </div>
          </div>
        </div>
      </section>

      <section className="container py-12">
        <div className="mb-8 flex flex-col justify-between gap-4 md:flex-row md:items-end">
          <div>
            <p className="text-sm uppercase tracking-[0.35em] text-aris-champagne">Curated matches</p>
            <h2 className="mt-3 font-display text-4xl md:text-5xl">Homes with personality</h2>
          </div>
          <div className="flex gap-2">
            <Button asChild variant="outline"><Link href="/map"><Map className="mr-2 h-4 w-4" /> Open map</Link></Button>
            <Button asChild variant="luxury"><Link href="/matches">Open vertical feed <ArrowRight className="ml-2 h-4 w-4" /></Link></Button>
          </div>
        </div>
        <PropertyGrid properties={properties} />
      </section>

      <section className="container grid gap-6 py-16 md:grid-cols-3">
        {[
          { icon: WandSparkles, title: 'Natural language search', body: 'Describe the home in your own words and let AI parse budget, location, features, and lifestyle intent.' },
          { icon: Camera, title: 'Photo-to-vibe matching', body: 'Upload an inspiration image or paste a Pinterest link to discover visually similar properties.' },
          { icon: Sparkles, title: 'Seller Listing Studio', body: 'Turn photos and notes into premium listing copy, SEO content, vibe tags, pricing suggestions, and captions.' }
        ].map((feature) => {
          const Icon = feature.icon;
          return (
            <div key={feature.title} className="rounded-[2rem] border border-white/10 bg-white/[0.04] p-6">
              <Icon className="h-7 w-7 text-aris-champagne" />
              <h3 className="mt-5 text-xl font-semibold">{feature.title}</h3>
              <p className="mt-3 text-sm leading-6 text-muted-foreground">{feature.body}</p>
            </div>
          );
        })}
      </section>
    </>
  );
}
