import Link from "next/link";
import { BarChart3, Bell, Home, LineChart, Users } from "lucide-react";
import { properties } from "@/lib/sample-data";
import { PropertyGrid } from "@/components/property/property-grid";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";

export default function DashboardPage() {
  return (
    <section className="container space-y-8 py-10">
      <div className="flex flex-col justify-between gap-4 md:flex-row md:items-end">
        <div>
          <p className="text-sm uppercase tracking-[0.35em] text-aris-champagne">Dashboard</p>
          <h1 className="mt-3 font-display text-5xl">Your real estate command center.</h1>
          <p className="mt-3 text-muted-foreground">Buyer matches, seller performance, agent leads, and AI-generated insights in one place.</p>
        </div>
        <Button asChild variant="luxury"><Link href="/listing-studio">Open Listing Studio</Link></Button>
      </div>

      <div className="grid gap-4 md:grid-cols-4">
        {[
          { label: 'Saved homes', value: '12', icon: Home },
          { label: 'New match alerts', value: '8', icon: Bell },
          { label: 'Seller leads', value: '31', icon: Users },
          { label: 'Market trend', value: '+4.8%', icon: LineChart }
        ].map((stat) => {
          const Icon = stat.icon;
          return <Card key={stat.label}><CardContent className="p-5"><Icon className="h-5 w-5 text-aris-champagne" /><p className="mt-4 text-3xl font-semibold">{stat.value}</p><p className="text-sm text-muted-foreground">{stat.label}</p></CardContent></Card>;
        })}
      </div>

      <div className="grid gap-6 lg:grid-cols-3">
        <Card className="lg:col-span-2">
          <CardHeader><CardTitle>Personalized buyer matches</CardTitle></CardHeader>
          <CardContent><PropertyGrid properties={properties.slice(0, 2)} /></CardContent>
        </Card>
        <Card>
          <CardHeader><CardTitle className="flex items-center gap-2"><BarChart3 className="h-5 w-5 text-aris-champagne" /> Seller performance</CardTitle></CardHeader>
          <CardContent className="space-y-4">
            {['Listing views', 'AI chat inquiries', 'Saved by buyers', 'Viewing requests'].map((label, index) => (
              <div key={label}>
                <div className="mb-2 flex justify-between text-sm"><span>{label}</span><span className="text-muted-foreground">{[1240, 86, 214, 19][index]}</span></div>
                <div className="h-2 rounded-full bg-white/10"><div className="h-2 rounded-full bg-aris-champagne" style={{ width: `${[82, 58, 76, 32][index]}%` }} /></div>
              </div>
            ))}
          </CardContent>
        </Card>
      </div>
    </section>
  );
}
