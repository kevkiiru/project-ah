import { VibeFeed } from "@/components/property/vibe-feed";
import { properties } from "@/lib/sample-data";

export default function MatchesPage() {
  return (
    <section className="container py-8">
      <div className="mb-6 max-w-3xl">
        <p className="text-sm uppercase tracking-[0.35em] text-aris-champagne">Infinite vibe feed</p>
        <h1 className="mt-3 font-display text-5xl">Swipe through homes that match your mood.</h1>
      </div>
      <VibeFeed properties={properties} />
    </section>
  );
}
