import { PropertyMap } from "@/components/map/property-map";
import { properties } from "@/lib/sample-data";
import { PropertyCard } from "@/components/property/property-card";

export default function MapPage() {
  return (
    <section className="container grid gap-6 py-10 xl:grid-cols-[1fr_420px]">
      <div>
        <div className="mb-6">
          <p className="text-sm uppercase tracking-[0.35em] text-aris-champagne">Map search</p>
          <h1 className="mt-3 font-display text-5xl">Clusters, heatmaps, and vibe geography.</h1>
          <p className="mt-3 max-w-2xl text-muted-foreground">Mapbox GL-ready map with markers today and a clear path for clusters, draw-search, commute overlays, and vibe heatmaps.</p>
        </div>
        <PropertyMap properties={properties} />
      </div>
      <aside className="space-y-4 xl:max-h-[760px] xl:overflow-y-auto xl:pt-28">
        {properties.map((property) => <PropertyCard key={property.id} property={property} />)}
      </aside>
    </section>
  );
}
