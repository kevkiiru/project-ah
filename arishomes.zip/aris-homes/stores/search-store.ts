import { create } from "zustand";
import type { VibeTag } from "@/types/property";

type SearchState = {
  query: string;
  selectedVibes: VibeTag[];
  maxPrice?: number;
  setQuery: (query: string) => void;
  toggleVibe: (tag: VibeTag) => void;
  setMaxPrice: (price?: number) => void;
  reset: () => void;
};

export const useSearchStore = create<SearchState>((set) => ({
  query: "",
  selectedVibes: [],
  maxPrice: undefined,
  setQuery: (query) => set({ query }),
  toggleVibe: (tag) =>
    set((state) => ({
      selectedVibes: state.selectedVibes.includes(tag)
        ? state.selectedVibes.filter((item) => item !== tag)
        : [...state.selectedVibes, tag]
    })),
  setMaxPrice: (maxPrice) => set({ maxPrice }),
  reset: () => set({ query: "", selectedVibes: [], maxPrice: undefined })
}));
