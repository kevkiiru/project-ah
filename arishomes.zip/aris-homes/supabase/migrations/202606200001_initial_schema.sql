-- Aris Homes initial Supabase schema
-- Enable in Supabase SQL editor or via `supabase db push`.

create extension if not exists "uuid-ossp";
create extension if not exists postgis;

create type public.user_role as enum ('buyer', 'seller', 'agent');
create type public.property_status as enum ('draft', 'active', 'pending', 'sold', 'archived');
create type public.conversation_kind as enum ('ai_concierge', 'owner_agent', 'support');
create type public.viewing_status as enum ('requested', 'confirmed', 'completed', 'cancelled');
create type public.offer_status as enum ('draft', 'submitted', 'countered', 'accepted', 'rejected', 'withdrawn');

create table public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  full_name text,
  avatar_url text,
  role public.user_role not null default 'buyer',
  phone text,
  vibe_preferences text[] not null default '{}',
  onboarding_completed boolean not null default false,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table public.properties (
  id uuid primary key default uuid_generate_v4(),
  owner_id uuid references public.profiles(id) on delete set null,
  agent_id uuid references public.profiles(id) on delete set null,
  title text not null,
  description text not null,
  price numeric(14,2) not null check (price >= 0),
  currency text not null default 'USD',
  address text not null,
  location text generated always as (address) stored,
  city text not null,
  state text not null,
  postal_code text,
  neighborhood text,
  beds numeric(4,1) not null default 0,
  baths numeric(4,1) not null default 0,
  sqft integer check (sqft is null or sqft > 0),
  lat double precision not null,
  lng double precision not null,
  geog geography(point, 4326) generated always as (st_setsrid(st_makepoint(lng, lat), 4326)::geography) stored,
  vibe_tags text[] not null default '{}',
  vibe_scores jsonb not null default '{}'::jsonb,
  ai_description text,
  ai_valuation jsonb not null default '{}'::jsonb,
  status public.property_status not null default 'draft',
  published_at timestamptz,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create index properties_geog_idx on public.properties using gist (geog);
create index properties_status_idx on public.properties (status);
create index properties_price_idx on public.properties (price);
create index properties_vibe_tags_idx on public.properties using gin (vibe_tags);
create index properties_city_state_idx on public.properties (city, state);

create table public.property_images (
  id uuid primary key default uuid_generate_v4(),
  property_id uuid not null references public.properties(id) on delete cascade,
  storage_path text not null,
  url text,
  alt text,
  sort_order integer not null default 0,
  is_hero boolean not null default false,
  ai_labels text[] not null default '{}',
  created_at timestamptz not null default now()
);
create index property_images_property_idx on public.property_images(property_id, sort_order);

create table public.saved_properties (
  user_id uuid not null references public.profiles(id) on delete cascade,
  property_id uuid not null references public.properties(id) on delete cascade,
  notes text,
  created_at timestamptz not null default now(),
  primary key (user_id, property_id)
);

create table public.user_searches (
  id uuid primary key default uuid_generate_v4(),
  user_id uuid not null references public.profiles(id) on delete cascade,
  query text,
  filters jsonb not null default '{}'::jsonb,
  vibe_tags text[] not null default '{}',
  alert_enabled boolean not null default false,
  alert_frequency text not null default 'daily',
  last_alerted_at timestamptz,
  created_at timestamptz not null default now()
);

create table public.conversations (
  id uuid primary key default uuid_generate_v4(),
  kind public.conversation_kind not null default 'ai_concierge',
  property_id uuid references public.properties(id) on delete set null,
  buyer_id uuid references public.profiles(id) on delete set null,
  seller_id uuid references public.profiles(id) on delete set null,
  agent_id uuid references public.profiles(id) on delete set null,
  messages jsonb not null default '[]'::jsonb,
  ai_summary text,
  last_message_at timestamptz not null default now(),
  created_at timestamptz not null default now()
);
create index conversations_participants_idx on public.conversations(buyer_id, seller_id, agent_id);

create table public.neighborhood_insights (
  id uuid primary key default uuid_generate_v4(),
  name text not null,
  city text not null,
  state text not null,
  center geography(point, 4326),
  boundary geography(multipolygon, 4326),
  vibe_profile jsonb not null default '{}'::jsonb,
  school_score numeric(4,2),
  walk_score integer,
  transit_score integer,
  market_trends jsonb not null default '{}'::jsonb,
  ai_report text,
  updated_at timestamptz not null default now(),
  unique(name, city, state)
);
create index neighborhood_center_idx on public.neighborhood_insights using gist(center);

create table public.viewings (
  id uuid primary key default uuid_generate_v4(),
  property_id uuid not null references public.properties(id) on delete cascade,
  buyer_id uuid not null references public.profiles(id) on delete cascade,
  agent_id uuid references public.profiles(id) on delete set null,
  requested_time timestamptz not null,
  confirmed_time timestamptz,
  status public.viewing_status not null default 'requested',
  notes text,
  created_at timestamptz not null default now()
);
create index viewings_property_idx on public.viewings(property_id, requested_time);
create index viewings_buyer_idx on public.viewings(buyer_id, requested_time);

create table public.offers (
  id uuid primary key default uuid_generate_v4(),
  property_id uuid not null references public.properties(id) on delete cascade,
  buyer_id uuid not null references public.profiles(id) on delete cascade,
  seller_id uuid references public.profiles(id) on delete set null,
  amount numeric(14,2) not null check (amount > 0),
  currency text not null default 'USD',
  contingencies jsonb not null default '{}'::jsonb,
  ai_draft text,
  status public.offer_status not null default 'draft',
  submitted_at timestamptz,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
create index offers_property_idx on public.offers(property_id, status);
create index offers_buyer_idx on public.offers(buyer_id, status);

create or replace function public.set_updated_at()
returns trigger language plpgsql as $$
begin
  new.updated_at = now();
  return new;
end;
$$;

create trigger profiles_updated_at before update on public.profiles for each row execute function public.set_updated_at();
create trigger properties_updated_at before update on public.properties for each row execute function public.set_updated_at();
create trigger offers_updated_at before update on public.offers for each row execute function public.set_updated_at();

create or replace function public.handle_new_user()
returns trigger language plpgsql security definer set search_path = public as $$
begin
  insert into public.profiles (id, full_name, avatar_url)
  values (new.id, new.raw_user_meta_data->>'full_name', new.raw_user_meta_data->>'avatar_url')
  on conflict (id) do nothing;
  return new;
end;
$$;

create trigger on_auth_user_created
after insert on auth.users
for each row execute function public.handle_new_user();

alter table public.profiles enable row level security;
alter table public.properties enable row level security;
alter table public.property_images enable row level security;
alter table public.saved_properties enable row level security;
alter table public.user_searches enable row level security;
alter table public.conversations enable row level security;
alter table public.neighborhood_insights enable row level security;
alter table public.viewings enable row level security;
alter table public.offers enable row level security;

-- Profiles
create policy "profiles are viewable by authenticated users" on public.profiles for select to authenticated using (true);
create policy "users update own profile" on public.profiles for update to authenticated using (auth.uid() = id) with check (auth.uid() = id);
create policy "users insert own profile" on public.profiles for insert to authenticated with check (auth.uid() = id);

-- Properties: public active listings; owners/agents manage their listings.
create policy "active properties are public" on public.properties for select using (status = 'active');
create policy "owners and agents can view own properties" on public.properties for select to authenticated using (owner_id = auth.uid() or agent_id = auth.uid());
create policy "sellers and agents insert properties" on public.properties for insert to authenticated with check (
  owner_id = auth.uid() or agent_id = auth.uid()
);
create policy "owners and agents update own properties" on public.properties for update to authenticated using (owner_id = auth.uid() or agent_id = auth.uid()) with check (owner_id = auth.uid() or agent_id = auth.uid());
create policy "owners and agents delete draft properties" on public.properties for delete to authenticated using ((owner_id = auth.uid() or agent_id = auth.uid()) and status = 'draft');

-- Property images follow property access.
create policy "property images public for active listings" on public.property_images for select using (
  exists (select 1 from public.properties p where p.id = property_id and p.status = 'active')
);
create policy "owners and agents manage property images" on public.property_images for all to authenticated using (
  exists (select 1 from public.properties p where p.id = property_id and (p.owner_id = auth.uid() or p.agent_id = auth.uid()))
) with check (
  exists (select 1 from public.properties p where p.id = property_id and (p.owner_id = auth.uid() or p.agent_id = auth.uid()))
);

-- Saved properties and searches are private to the user.
create policy "users manage own saved properties" on public.saved_properties for all to authenticated using (user_id = auth.uid()) with check (user_id = auth.uid());
create policy "users manage own searches" on public.user_searches for all to authenticated using (user_id = auth.uid()) with check (user_id = auth.uid());

-- Conversations: only participants can access.
create policy "conversation participants can view" on public.conversations for select to authenticated using (auth.uid() in (buyer_id, seller_id, agent_id));
create policy "conversation participants can insert" on public.conversations for insert to authenticated with check (auth.uid() in (buyer_id, seller_id, agent_id));
create policy "conversation participants can update" on public.conversations for update to authenticated using (auth.uid() in (buyer_id, seller_id, agent_id)) with check (auth.uid() in (buyer_id, seller_id, agent_id));

-- Neighborhood insights are public read; service role or dashboard jobs can write.
create policy "neighborhood insights public read" on public.neighborhood_insights for select using (true);

-- Viewings and offers: relevant parties only.
create policy "viewing participants manage" on public.viewings for all to authenticated using (
  buyer_id = auth.uid() or agent_id = auth.uid() or exists (select 1 from public.properties p where p.id = property_id and p.owner_id = auth.uid())
) with check (
  buyer_id = auth.uid() or agent_id = auth.uid() or exists (select 1 from public.properties p where p.id = property_id and p.owner_id = auth.uid())
);

create policy "offer participants manage" on public.offers for all to authenticated using (
  buyer_id = auth.uid() or seller_id = auth.uid() or exists (select 1 from public.properties p where p.id = property_id and (p.owner_id = auth.uid() or p.agent_id = auth.uid()))
) with check (
  buyer_id = auth.uid() or seller_id = auth.uid() or exists (select 1 from public.properties p where p.id = property_id and (p.owner_id = auth.uid() or p.agent_id = auth.uid()))
);

-- Storage bucket recommendation:
-- insert into storage.buckets (id, name, public) values ('property-images', 'property-images', true);
-- Add storage policies scoped by property ownership when upload flows are enabled.
